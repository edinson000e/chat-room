<?php
/**
 * Render your site front page, whether the front page displays the blog posts index or a static page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#front-page-display
 *
 * @package TexasHoldemPoker
 */

get_header();

/*
* Include the component stylesheet for the content.
* This call runs only once on index and archive pages.
* At some point, override functionality should be built in similar to the template part below.
*/
wp_print_styles( array( 'TexasHoldemPoker-content', 'TexasHoldemPoker-front-page' ) ); // Note: If this was already done it will be skipped.
global $wpdb;
$promotion = $wpdb->prefix.'promotions';
$registers= $wpdb->get_results('SELECT * FROM '.$promotion,ARRAY_A);
?>

<div class="contenedor-grid carousel" style="">
	<amp-carousel width="300" height="100" layout="responsive" type="slides">
  		<?php foreach ($registers as $register) :?>
			<div >
			<amp-img src="<?php echo get_stylesheet_directory_uri()."/img/theme/home/".$register['image']; ?>" width="300" height="168" layout="responsive" > </amp-img>
			<div class="transparent">
				<div  class="information_promotion">
				<p class="title">
					<b>
					<?php echo $register['title']; ?>
					</b>
				</p>
				<p class="description"><?php echo $register ['description']; ?> </p>
				<?php if (isset($register ['button']) and (!empty ( $register ['button']))):?>


				<a href="<?php echo $register ['link']; ?>"  target=”_blank” >
					<button><?php echo $register ['button']; ?></button>
				</a>

				<?php endif; ?>
				</div>
			</div>
			</div>
		<?php endforeach; ?>
	</amp-carousel>
</div>

<div class="abe-preview fit mb1 lastest_new">
  <div class="parallax-amp" id="top-part" >
    <div class="container">
      <center>
        <h2>Latest News</h2>
        <p> Know the latest in texasholdempoker.com where you can give a spin your knowledge</p>
        </center>
    </div>
  </div>
</div>

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'front' );

		endwhile; // End of the loop.
		?>
		<?php the_posts_navigation(); ?>

	</main><!-- #primary -->

<?php

get_footer();
