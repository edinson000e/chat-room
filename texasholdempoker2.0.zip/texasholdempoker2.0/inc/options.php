<?php

function add_theme_caps() {
    // gets the author role
    $role = get_role( 'editor','administrator' );

    // This only works, because it accesses the class instance.
    // would allow the author to edit others' posts for current theme only
    $role->add_cap( 'manage_wpse_173073' );

    $role = get_role( 'administrator' );
      $role->add_cap( 'manage_wpse_173073' );
}
add_action( 'admin_init', 'add_theme_caps');



function thp_settings (){
	//nombre del a pagina /nombre q se vera en el menu/ rol / loop / como se va a llamar/ icono / posicion




	add_menu_page ('TexasHoldemPoker.com','THP Settings','manage_wpse_173073','thp_settings','thp_options','',20);

	//lop// nombre de la pag// titulo del menu
	add_submenu_page('thp_settings','Promotions','Promotions','manage_wpse_173073','thp_promotions','thp_promotions');


	add_submenu_page('thp_settings','Add New','Add New','manage_wpse_173073','thp_promotions_add_new','thp_promotions_add_new');


	//call the registry of the options of our theme


	add_action('admin_init','thp_register_options');

}

add_action ('admin_menu','thp_settings');

function thp_register_options(){
	//Register options, one per fields
	//dos párametros grupos
	register_setting ('thp_group','thp_address');
	register_setting ('thp_group','thp_phone');
	register_setting ('thp_group','thp_copyrigh');
	register_setting ('thp_group','thp_img_logo');

}

function wpdocs_my_page_capability( $capability ) {
    return 'edit_others_posts';
}
add_filter( 'option_page_capability_thp_group', 'wpdocs_my_page_capability' );




function thp_options(){
	?>
	<div class="wrap">
		<h1>THP Settings</h1>

		<form method="post" action="options.php">
			<?php settings_fields( 'thp_group' ); ?>

			<?php  do_settings_sections('thp_groups'); ?>

			<?php //var_dump(get_option('thp_address')); ?>
			<table class="form-table">
				<!--
				<tr valign="top">
					<th scope="row">Direccion</th>
					<td><input type="text" name="thp_address" value="<?php echo esc_attr (get_option('thp_address'));  ?> " class="regular-text"></td>
				</tr>
				<tr valign="top">
					<th scope="row">Telefono</th>
					<td><input type="text" name="thp_phone" value="<?php echo esc_attr (get_option('thp_phone'));  ?> " class="regular-text"></td>


				</tr> -->
				<tr valign="top">
					<th scope="row">Copyright</th>
					<td><input type="text" name="thp_copyrigh" value="<?php echo esc_attr (get_option('thp_copyrigh'));  ?> " class="regular-text"></td>


				</tr>
				<tr valign="top">
					<th scope="row">Logo image</th>
					<td><input type="file" name="thp_img_logo" value="<?php echo esc_attr (get_option('thp_img_logo'));  ?> " class="regular-text"></td>


				</tr>
			</table>
			<?php  submit_button() ?>
		</form>
	</div>

<?php
}

function thp_promotions(){
		//OBJETCT
	//ARRAY_N

	global $wpdb;
	$promotion = $wpdb->prefix.'promotions';
	$registers= $wpdb->get_results('SELECT * FROM '.$promotion,ARRAY_A);

	?>

		<div class="wrap ">
			<h1>Promotions</h1>
			<table class="wp-list-table widefat striped">
				<thead >
					<tr>
						<th class="manage-column"> Id</th>
						<th class="manage-column"> Title</th>
						<th class="manage-column"> Descripcion</th>
						<th class="manage-column"> Imagen </th>
						<th class="manage-column"> Link</th>
						<th class="manage-column"> Contents of the button</th>
					</tr>
				</thead>

				<tbody>
					<?php

						foreach ($registers as $register) :?>

						<tr>
							<td><?php echo $register['id']; ?></td>
							<td><?php echo $register['title']; ?></td>
							<td><?php echo $register['description']; ?></td>
							<td>
								<div class="inside">
									<table >
										<tr>
											<td>

											<img width="150" height="111" src="<?php echo get_stylesheet_directory_uri ()."/img/theme/home/".$register['image']; ?>" >
											</td>

										</tr>
									</table>
								</div>
							</td>
							<td><?php echo $register['link']; ?></td>
							<td><?php echo $register['button']; ?></td>
						</tr>


					<?php endforeach; ?>
				</tbody>
			</table>
		</div>



	<?php


}

function thp_promotions_add_new (){
if ($_GET ['sent'] ){
?>
	<div id="message" class="updated notice notice-success is-dismissible"><p>Datos guardado <button type="button" class="notice-dismiss"><span class="screen-reader-text">Descartar este aviso.</span></button></div>

	<?php
}
	?>

	<div id="col-container">
		<div class="wrap">
				<h1>Add New Promotion</h1>
			</div>
			<div class="form-wrap">

<form id="addtag" method="post" action="<?php echo admin_url( 'admin-post.php' ) ?>" class="validate" enctype="multipart/form-data" target="_blank"   >
<input type="hidden" name="action" value="promotions_action_hook">
<div class="form-field form-required term-name-wrap">
	<label for="tag-title">Title</label>
	<input name="tag-title" id="tag-title" type="text" value="" size="40" aria-required="true">

</div>

<div class="form-field term-description-wrap">
	<label for="tag-description">Descripción</label>
	<textarea name="tag-description" id="tag-description" rows="5" cols="40"></textarea>

</div>
<div class="form-field term-description-wrap">
	<label for="tag-imagen">Imagen</label>
	<input name="tag-imagen" id="tag-imagen" type="file" accept="image/gif, image/jpeg">

</div>
<div class="form-field term-slug-wrap">
	<label for="tag-link">Link</label>
	<input name="tag-link" id="tag-link" type="text" value="" size="40">

</div>

<div class="form-field term-slug-wrap">
	<label for="tag-contents-button">Contents of the button</label>
	<input name="tag-contents-button" id="tag-contents-button" type="text" value="" size="40">

</div>

		</tbody></table>
</div>

<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Añadir nueva categoría"></p></form></div>
	</div>
		<?php

}

add_action( 'admin_post_promotions_action_hook', 'thp_promotions_action_hook_function' );
function thp_promotions_action_hook_function() {
$datas[]=array('title'=> sanitize_text_field($_POST['tag-title']));
$datas[] = array('description'=> sanitize_textarea_field($_POST['tag-description']));
//$datas[] =array('imagen'=>  sanitize_file_name($_POST['tag-imagen']));
$datas[] = array('imagen'=> sanitize_file_name ($_POST['tag-imagen']));
$datas[] = array('link'=> sanitize_text_field($_POST['tag-link']));
$datas[] = array('button'=> sanitize_text_field($_POST['tag-contents-button']));


$upload_dir_var= get_theme_file_uri('/img/theme/home');
var_dump($upload_dir_var);
	echo('<br>');

	$upload_dir = get_template_directory().'/img/theme/home';
	var_dump($upload_dir);
	echo('<br>');

	$filename = basename ($_FILES['tag-imagen']['name']); // file name
	$filename = trim($filename); //Remove possible spaces before and after the filename
	var_dump($filename);
		echo('<br>');
	$typefile = $_FILES ['tag-imagen']['type']; // We obtain the file type, format

	$uploaddir = realpath($upload_dir); //Verify Path
		var_dump($uploaddir);
	echo('<br>');

	$uploadfile = $uploaddir.'/'.$filename; // Name format
	var_dump($uploadfile);
	echo('<br>');
	$slugname = preg_replace('/\.[^.]+$/', '', basename($uploadfile)); //Image name in the database

	if ( file_exists ($uploadfile) ) { // Check for that name
	      $count = "0";
	      while ( file_exists($uploadfile) ) {
	      $count++;
	      if ( $typefile == 'image/jpeg' ) { $exten = 'jpg'; }
	      elseif ( $typefile == 'image/png' ) { $exten = 'png'; }
		  elseif ( $typefile == 'image/gif' ) { $exten = 'gif'; }else
		  $exten = 'jpg';

	      $uploadfile = $uploaddir.'/'.$slugname.'-'.$count.'.'.$exten;
	      }
	} // end if file_exists


	if (move_uploaded_file($_FILES['tag-imagen']['tmp_name'], $uploadfile)) {
	     	$slugname = preg_replace('/\.[^.]+$/', '', basename($uploadfile));


	     	$slugname=$slugname.'.'.$exten;


			global $wpdb;
			$promotion = $wpdb->prefix.'promotions';


			$wpdb-> query ($wpdb-> prepare ("
					INSERT INTO $promotion
					(title,description,image,link,button)
					values (%s,%s,%s,%s,%s)
				",

			        array (
				        $datas[0]['title'],
				        $datas[1]['description'],
				        $slugname,
				        $datas[3]['link'],
				        $datas[4]['button']
					)
			));

			$wpdb->show_errors();
				   echo "no error";
		}
	else {
	      //  error
		echo "error";
	}







/*

echo "<br><br><br>";
echo $_FILES['tag-imagen']['name'];

echo"<br>";echo"<br>";echo"<br>";


	$upload_dir_var= get_theme_file_uri('/img/theme/home');
	$upload_dir = get_template_directory().'/img/theme/home';
	$filename = basename($_FILES['tag-imagen']['name']); // file name
	$filename = trim($filename); //Remove possible spaces before and after the filename

	$typefile = $_FILES['tag-imagen']['type']; // We obtain the file type, format

	$uploaddir = realpath($upload_dir); //Verify Path

	$uploadfile = $uploaddir.'/'.$filename; // Name format

	$slugname = preg_replace('/\.[^.]+$/', '', basename($uploadfile)); //Image name in the database

	if ( file_exists($uploadfile) ) { // Check for that name
	      $count = "0";
	      while ( file_exists($uploadfile) ) {
	      $count++;
	      if ( $typefile == 'image/jpeg' ) { $exten = 'jpg'; }
	      elseif ( $typefile == 'image/png' ) { $exten = 'png'; }
	      elseif ( $typefile == 'image/gif' ) { $exten = 'gif'; }
	      $uploadfile = $uploaddir.'/'.$slugname.'-'.$count.'.'.$exten;
	      }
	} // end if file_exists

	if (move_uploaded_file($_FILES['tag-imagen']['tmp_name'], $uploadfile)) {
	     	$slugname = preg_replace('/\.[^.]+$/', '', basename($uploadfile));
	     	$slugname.'.'.$exten."<br><br>";

		}
	else {
	      //  error
	}
*/

}


function thp_insert_promotions_action_hook_function () {


}

function thp_alert (){

}
