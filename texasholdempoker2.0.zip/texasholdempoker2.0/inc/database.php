<?php



function thp_database(){

    //wpdb da los metodos para trabajar ocn tablas

    global $wpdb;

    //agregar versiones
    global $thp_dbversion;
    $thp_dbversion= '1.0';


    //obtener el prefijo de la bd
    $tabla= $wpdb->prefix .'promotions';

    //obtener el collation de la instalacion
    $charset_collate = $wpdb->get_charset_collate ();    

    //agregar estrucutra de la bd

      $sql= "
    CREATE TABLE $tabla ( 
        id mediumint(9)NOT NULL AUTO_INCREMENT, 
        title varchar (20) NOT NULL, 
        description varchar (50) NOT NULL, 
        image longtext DEFAULT '' NOT NULL, 
        link longtext DEFAULT '' NOT NULL, 
        button varchar (20) DEFAULT '' NOT NULL,
        PRIMARY KEY (id) 
    ) $charset_collate; 

     ";

    //se necesita dbdelta para ejecutar el sql y esta en lsiguiente direccion
    require_once (ABSPATH .'wp-admin/includes/upgrade.php');    
    dbDelta ($sql);

    // actualizar en caso de ser necesario

         // agregar la version de la bd para comparar con la futuras actualizaciones
        add_option ('thp_version',$thp_dbversion);

        //actualizar en caso de ser necesario 
         $current_version=get_option('thp_version');

         // comparar las dos versioens
    if ($thp_dbversion != $current_version ){

        $tabla= $wpdb->prefix .'reservaciones';
        $charset_collate = $wpdb->get_charset_collate ();    

        // realizar las actualizaciones 
          $sql= "
        CREATE TABLE $tabla ( 
            id mediumint(9)NOT NULL AUTO_INCREMENT, 
            title varchar (20) NOT NULL, 
            description varchar (50) NOT NULL, 
            image longtext DEFAULT '' NOT NULL, 
            link longtext DEFAULT '' NOT NULL, 
            button varchar (20) DEFAULT '' NOT NULL,
            PRIMARY KEY (id) 
        ) $charset_collate; 

         ";
           require_once (ABSPATH .'wp-admin/includes/upgrade.php');    
        dbDelta ($sql);
        update_option ('thp_version',$thp_dbversion);

    }
}


add_action ('after_setup_theme','thp_database');


// funcion para comprobar q la version instalada es igual a la base de datos nueva

function thp_check (){

    global $thp_dbversion;
    if (get_site_option('thp_dbversion') != $thp_dbversion){

        thp_database();
    }
}

add_action ('plugins_loaded','thp_check');