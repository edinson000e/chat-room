<?php 
echo 'hola';
function thp_save(){
	if (isset($_POST['enviar'])){
		echo "hola";
	}
}

add_action ('init','thp_save');