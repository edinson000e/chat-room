'use strict';

(function ($) {
	$(document).ready(function () {
		var data2 = glossary.words;
		data2 = $.parseJSON(data2);
		$('#search-glossary').on('keyup', search);
		$('#search-glossary').html(showAllGlossary);
	});

	function showAllGlossary() {
		data = searchWordGlossary(data2, '');
		showGLossary(data);
	}

	function searchWordGlossary(data, search) {
		var data_words = new Array();
		for (var i = 0; i < data.length; i++) {
			data[i].post_title.toLowerCase();
			if (data[i].post_title.indexOf(search) == 0) data_words.push(data[i]);
		}
		return data_words;
	}

	function showGLossary(data) {
		var html;
		html = '';
		if (data.length) {
			html = 'Result of your search engine:' + data.length;

			$.each(data, function (pos, item) {
				html = html + "<li class='ln-_'>" + "<a class='glossaryLink' href= '" + item.guid + "' data-cmtooltip='" + item.post_excerpt + "'>" + item.post_title + "</a>" + "</li>";
			});
		} else {
			html = 'No matching entries';
		}

		$('.glossaryList').html(html);
	}

	function search(evento) {
		var search = $('#search-glossary').val();
		var html = "";
		var data = glossary.words;
		data = $.parseJSON(data);
		data = searchWordGlossary(data, search);
		showGLossary(data);
	}
})(jQuery);