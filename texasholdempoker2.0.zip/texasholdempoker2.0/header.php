<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package TexasHoldemPoker
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<?php if ( ! TexasHoldemPoker_is_amp() ) : ?>
		<script>document.documentElement.classList.remove("no-js");</script>
	<?php endif; ?>

	<?php wp_head(); ?>
	<script src="https://cdn.socket.io/socket.io-1.4.5.js"></script>
</head>
<body <?php body_class(); ?>>

	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'TexasHoldemPoker' ); ?></a>
		<header id="masthead" class="site-header">

			<div class="site-branding">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"> <?php the_custom_logo(); ?> </a>
			</div><!-- .site-branding -->

			<nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e( 'Main menu', 'TexasHoldemPoker' ); ?>"
				<?php if ( TexasHoldemPoker_is_amp() ) : ?>
					[class]=" siteNavigationMenu.expanded ? 'main-navigation toggled-on' : 'main-navigation' "
				<?php endif; ?>
			>
				<?php if ( TexasHoldemPoker_is_amp() ) : ?>
					<amp-state id="siteNavigationMenu">
						<script type="application/json">
							{
								"expanded": false
							}
						</script>
					</amp-state>
				<?php endif; ?>

				<button class="menu-toggle" aria-label="<?php esc_attr_e( 'Open menu', 'TexasHoldemPoker' ); ?>" aria-controls="primary-menu" aria-expanded="false"
					<?php if ( TexasHoldemPoker_is_amp() ) : ?>
						on="tap:AMP.setState( { siteNavigationMenu: { expanded: ! siteNavigationMenu.expanded } } )"
						[aria-expanded]="siteNavigationMenu.expanded ? 'true' : 'false'"
					<?php endif; ?>
				>
					<?php esc_html_e( 'Menu', 'TexasHoldemPoker' ); ?>
				</button>

				<div class="primary-menu-container">
					<?php

					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'menu_id'        => 'primary-menu',
							'container'      => 'ul',
						)
					);

					?>
				</div>
			</nav><!-- #site-navigation -->
		
 <input type="checkbox" id="spoiler1"></input>
	<label for="spoiler1" class='spoiler2'><i class="fa fa-chevron-down"></i>
</label> 

    	<div class="container-chat">
      		
      		<div class="sectionUsers">
        		<div id="seccionUsuarios" class="jumbotron">
          			<h2>Users</h2>
          			<div id="listaUsuarios"></div>
        		</div>
      		</div>
      		<div class="container" >
        		<ul class="chatbox" id="chatbox">
			        <?php
			            if(get_current_user_id()=="0"){
			              echo "<h2><center>Login to join chat room</center></h2>";
			            }
			        ?>
        		</ul>

		        <div id="name-group" class="form-group">
		            <textarea class="form-control msg_box" id="msg_box" placeholder="Type here and check the Title in Tab"></textarea>
		        </div>
      		</div>
      	</div>
  

	</header><!-- #masthead -->
	<div id="page" class="site">
