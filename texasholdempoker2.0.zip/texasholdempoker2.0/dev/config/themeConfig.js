'use strict';

module.exports = {
	theme: {
		slug: 'TexasHoldemPoker',
		name: 'TexasHoldemPoker version 2.0',
		author: 'smart64'
	},
	dev: {
		browserSync: {
			live: true,
			proxyURL: 'localhost:8080/wordpress/',
			bypassPort: '8282'
		},
		browserslist: [ // See https://github.com/browserslist/browserslist
			'> 1%',
			'last 2 versions'
		],
		debug: {
			styles: true, // Render verbose CSS for debugging.
			scripts: false // Render verbose JS for debugging.
		}
	},
	export: {
		compress: false
	}
};
