'use strict';
const process = require('process');
const Knex = require('knex');
const crypto = require('crypto');
const bodyParser = require('body-parser');
var http = require('http');
var express = require('express');
var request = require('request');
const dateFormat = require('dateformat');
var app = express();
var users = [];
var now ;
var today;

app.enable('trust proxy');


app.set('view engine', 'jade');



function insertVisit (knex, visit) {
  return knex('messages').insert(visit);
}

function getVisits (knex) {

  return knex.select('id', 'messages','uid','time')
    .from('messages')
    .orderBy('id', 'desc')
    .limit(10)
    .then((results) => {
      return results.map((visit) => `Time: ${visit.messages}, AddrHash: ${visit.time}`);
    });
}

//app.use(require("express").static('data'));
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

/*
app.get('/', function (req, res) {
 
});*/

app.get('/', function (req, res) {
  // res.sendFile(__dirname + '/index.html');
  getExternalIp(function (externalIp) {
    res.render('index.jade', {externalIp: externalIp});
  });
});


var METADATA_NETWORK_INTERFACE_URL = 'http://metadata/computeMetadata/v1/' +
    '/instance/network-interfaces/0/access-configs/0/external-ip';

function getExternalIp (cb) {
  var options = {
    url: METADATA_NETWORK_INTERFACE_URL,
    headers: {
      'Metadata-Flavor': 'Google'
    }
  };

  request(options, function (err, resp, body) {
    if (err || resp.statusCode !== 200) {
      console.log('Error while talking to metadata server, assuming localhost');
      return cb('localhost');
    }
    return cb(body);
  });
}

var server = app.listen(65080);
var io = require('socket.io')(server);

const knex = connect();
function connect () {
  // [START connect]
  const config = {
    host:'35.238.81.186',
    user:'smart64',
    password:'FYqBFbP*2XDbyb',
    database: 'wpdatabase',
     port:'3306'
  };

 
  if (process.env.INSTANCE_CONNECTION_NAME && process.env.NODE_ENV === 'production') {
    config.socketPath = `/cloudsql/${process.env.INSTANCE_CONNECTION_NAME}`;
  }

  // Connect to the database
  const knex = Knex({
    client: 'mysql',
    connection: config
  });
  // [END connect]

  return knex;
}

io.on('connection', function (socket) {

  console.log('user connected');
  socket.on('validate',function(data){
    var id= data.id;
    var nickname=data.nickname;
    var rol=data.rol;
    socket.nickname=nickname;
    
    if (rol.includes( 'administrator' )){
      socket.nickname=data.nickname+' (admin)';
      socket.rol=true;
    }else{
      socket.rol=false;
    }
    //users.push('id'=>id,'nickname'=>nickname,'roles'=>rol);
    

users.push({id: id, nickname: nickname, rol: rol});
    io.emit('user entrance',{
     
      id:data.id,
      nickname:nickname
    }); 
    //io.emit('updateUsers', users);
   
  });


  socket.on('chat_message', function (data) {

    now = new Date();
    today=dateFormat(now, "yyyy-mm-dd HH:MM");
    const visit = {
    time:  today,
    id:data.id,
    uid:data.id,
    messages:data.msg
  };


  insertVisit(knex, visit);
    // Query the last 10 visits from the database.
  

  knex('messages').max('id as max').then(function(rows) {

  io.emit('get msg',{table:rows,message:data.msg,id:data.id,date:today,rol:'administrator'});

})

  });

   socket.on('disconnect', function(){
   console.log('user disconnected');
     if(typeof(socket.nickname) == "undefined")
      {
        return;
      }
        users=removeItemFromArr(users,socket.nickname);
        io.emit('exit',{message:socket.nickname});
        
        io.emit('updateUsers', users);
        function removeItemFromArr ( arr, item ) {
        return arr.filter( e => e !== item );
        };
 });
});




var server = http.createServer(app).listen(process.env.PORT || '80', function () {
  console.log('App listening on port %s', server.address().port);
  console.log('Press Ctrl+C to quit.');
});

process.on('uncaughtException', function (err) {
    console.log(err);
}); 